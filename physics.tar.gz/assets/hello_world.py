import pygame
from pygame.math import Vector2

pygame.init()

#constants and colors
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 800
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
#100 pixels (2 background square lengths) = 1 meter

BGWHITE = (255, 255, 255)
BGGREY = (225, 225, 225)
BLACK = (0, 0, 0)

#list where all the blocks are stored
blocks = []

#object for the blocks; TODO: add rotation
class Block:
    def __init__(self, x, y, sx, sy):
        self.posx = x
        self.posy = y
        self.sizex = sx
        self.sizey = sy
        self.velx = 0.0
        self.vely = 0.0
        self.mass = (self.sizex * self.sizey) / 10.0
        self.netForce = pygame.math.Vector2((0.0, 0.0))
        self.anchored = False

        self.body = pygame.Surface((sx, sy))
        self.body.fill(BLACK)
        blocks.append(self)
        screen.blit(self.body, (self.posx, self.posy))
        self.hitbox = pygame.mask.from_surface(self.body)

    #update velocity + position; TODO: add rotation
    def move(self):
        if self.anchored:
            screen.blit(self.body, (self.posx, self.posy))
            return
        self.velx += (self.netForce.x / self.mass) / (100.0 / 60.0)
        self.vely += (self.netForce.y / self.mass) / (100.0 / 60.0)
        self.posx += self.velx / (100.0 / 60.0)
        self.posy += self.vely / (100.0 / 60.0)
        screen.blit(self.body, (self.posx, self.posy))

    #TODO: rotational momentum
    def collide(self, point, block):
        totalMass = self.mass + block.mass
        vel1x = ((self.mass - block.mass) * self.velx + 2 * block.mass * block.velx) / totalMass
        vel1y = ((self.mass - block.mass) * self.vely + 2 * block.mass * block.vely) / totalMass
        vel2x = ((block.mass - self.mass) * block.velx + 2 * self.mass * self.velx) / totalMass
        vel2y = ((block.mass - self.mass) * block.vely + 2 * self.mass * self.vely) / totalMass
        #i have no idea how the hell the youtube tutorial got that formula but im just gonna roll with it
        self.velx = vel1x
        self.vely = vel1y
        block.velx = vel2x
        block.vely = vel2y

        #/\ momentum
        #\/ forces
        
        if (abs(self.netForce.x) > abs(block.netForce.x)):
            difference = abs(self.netForce.x) - abs(block.netForce.x)
            if self.netForce.x > 0:
                block.netForce.x += difference
                self.netForce.x -= difference
            else:
                block.netForce.x -= difference
                self.netForce.x += difference
        else:
            difference = abs(block.netForce.x) - abs(self.netForce.x)
            if block.netForce.x > 0:
                self.netForce.x += difference
                block.netForce.x -= difference
            else:
                self.netForce.x -= difference
                block.netForce.x += difference
        
        if (abs(self.netForce.y) > abs(block.netForce.y)):
            difference = abs(self.netForce.y) - abs(block.netForce.y)
            if self.netForce.y > 0:
                block.netForce.y += difference
                self.netForce.y -= difference
            else:
                block.netForce.y -= difference
                self.netForce.y += difference
        else:
            difference = abs(block.netForce.y) - abs(self.netForce.y)
            if block.netForce.y > 0:
                self.netForce.y += difference
                block.netForce.y -= difference
            else:
                self.netForce.y -= difference
                block.netForce.y += difference
        if block.anchored and self.netForce == (0, 0):
            self.velx = 0
            self.vely = 0
            


#per frame updates
def update():
    #draw background
    w = SCREEN_WIDTH // 100
    h = SCREEN_HEIGHT // 50
    for i in range(w):
        for j in range(h):
            if (j % 2) == 0:
                pygame.draw.rect(screen, BGWHITE, ((i * 100), (j * 50), 50, 50))
                pygame.draw.rect(screen, BGGREY, ((i * 100 + 50), (j * 50), 50, 50))
            else:
                pygame.draw.rect(screen, BGWHITE, ((i * 100 + 50), (j * 50), 50, 50))
                pygame.draw.rect(screen, BGGREY, ((i * 100), (j * 50), 50, 50))

        #update hitboxes
    for block in blocks: 
        block.hitbox = pygame.mask.from_surface(block.body)
        if not block.anchored:
            block.netForce.y = 1000.0
        else:
            block.netForce = pygame.math.Vector2(0, 0)
    #collision detection
    for block in blocks:
        for i in blocks:
            if block.anchored:
                continue
            intPoint = block.hitbox.overlap(i.hitbox, ((i.posx - block.posx), (i.posy - block.posy))) #could definitely optimize but if it works it works
            if not ((intPoint == None) or (intPoint == (0, 0))):
                block.collide(intPoint, i)
        block.move()


    pygame.display.update()
    


block1 = Block(350, 200, 100, 100)
block2 = Block(50, 600, 700, 100)
block2.anchored = True

run = True
while run: #main game loop

    dt = pygame.time.Clock().tick(60)
    update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

pygame.quit()